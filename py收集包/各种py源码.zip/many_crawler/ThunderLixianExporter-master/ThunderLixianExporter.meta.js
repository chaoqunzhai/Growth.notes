// ==UserScript==
// @name       ThunderLixianExporter
// @namespace  http://dynamic.cloud.vip.xunlei.com/
// @version    0.78
// @description  export thunder lixian url to aria2/wget
// @include      http://dynamic.cloud.vip.xunlei.com/user_task*
// @include      http://lixian.vip.xunlei.com/lx3_task.html*
// @include      http://jiayuan.xunlei.com/lxhome/lx3_task.html*
// @include      http://cloud.vip.xunlei.com/*
// @run-at document-end
// @copyright  2012+, Binux <root@binux.me>
// @updateURL http://s.binux.me/TLE/master/ThunderLixianExporter.meta.js
// ==/UserScript==
